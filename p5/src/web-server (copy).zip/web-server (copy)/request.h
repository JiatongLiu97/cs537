#ifndef __REQUEST_H__

int requestHandle(int fd);

#endif
